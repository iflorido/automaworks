// ── HELPERS ─────────────────────────────────────────────────────────────────
const fmt  = (n, d=0) => n.toLocaleString('es-ES', {minimumFractionDigits:d, maximumFractionDigits:d});
const fmtE = (n, d=0) => fmt(n,d) + ' €';
const fmtP = (n, d=2) => fmt(n,d) + ' %';
const clamp = (v,a,b) => Math.min(Math.max(v,a),b);
const $ = id => document.getElementById(id);

// ── STATE ────────────────────────────────────────────────────────────────────
const S = {
    capital:   150000,
    down:      30000,
    rate:      3.5,
    years:     25,
    openFee:   0.5,
    insurance: 35,
    notary:    2000,
    income:    3500,
    loanType: 'hipoteca'
};

// Preset configs per loan type
const PRESETS = {
    hipoteca: { capitalMin:10000, capitalMax:1000000, capitalDef:150000, downPct:0.2,
                rateDef:3.5,  yearsMax:40, yearsDef:25, openFeeDef:0.5, insuranceDef:35, notaryDef:2000 },
    personal: { capitalMin:1000,  capitalMax:100000,  capitalDef:15000,  downPct:0,
                rateDef:8.5,  yearsMax:10, yearsDef:5,  openFeeDef:1.0,  insuranceDef:15, notaryDef:0 },
    coche:    { capitalMin:2000,  capitalMax:150000,  capitalDef:25000,  downPct:0.1,
                rateDef:6.5,  yearsMax:8,  yearsDef:5,  openFeeDef:0.5,  insuranceDef:20, notaryDef:300 }
};

// ── CORE FINANCE ─────────────────────────────────────────────────────────────
function calcMonthly(principal, annualRate, years) {
    if (annualRate === 0) return principal / (years * 12);
    const r = annualRate / 100 / 12;
    const n = years * 12;
    return principal * r * Math.pow(1+r, n) / (Math.pow(1+r, n) - 1);
}

// TAE estimation (includes all costs amortized over loan term)
function calcTAE(principal, monthly, years, openFee, insurance, notary) {
    const totalCashOut = openFee / 100 * principal + notary;
    const netReceived  = principal - totalCashOut; // dinero neto que recibes
    const monthlyReal  = monthly + insurance;
    const n = years * 12;
    // Solve IRR monthly via Newton-Raphson
    let r = S.rate / 100 / 12;
    for (let i = 0; i < 100; i++) {
        const pv = monthlyReal * (1 - Math.pow(1+r,-n)) / r;
        const dpv = (monthlyReal / r) * (
            (1 - Math.pow(1+r,-n)) / r - n * Math.pow(1+r,-n-1)
        );
        const f  = pv - netReceived;
        const df = dpv;
        r -= f / df;
        if (r <= 0) { r = 0.001; break; }
    }
    return (Math.pow(1+r,12) - 1) * 100;
}

function buildSchedule(principal, annualRate, years) {
    const r = annualRate / 100 / 12;
    const n = years * 12;
    const monthly = calcMonthly(principal, annualRate, years);
    let balance = principal;
    const rows = [];
    for (let i = 1; i <= n; i++) {
        const interest = balance * r;
        const capital  = monthly - interest;
        balance        = Math.max(0, balance - capital);
        rows.push({ month:i, quota:monthly, capital, interest, balance });
    }
    return rows;
}

// ── RENDER ───────────────────────────────────────────────────────────────────
function render() {
    const { capital, down, rate, years, openFee, insurance, notary, income } = S;
    const principal = Math.max(1000, capital - down);
    const monthly   = calcMonthly(principal, rate, years);
    const monthlyTotal = monthly + insurance;
    const n         = years * 12;
    const totalQuotas = monthly * n;
    const totalInterest = totalQuotas - principal;
    const openFeeAmt = openFee / 100 * principal;
    const extraCosts = openFeeAmt + notary + insurance * n;
    const grandTotal = principal + totalInterest + openFeeAmt + notary;
    const tae = calcTAE(principal, monthly, years, openFee, insurance, notary);

    // Hero
    $('monthlyPayment').textContent = fmtE(monthly, 2);
    $('monthlyPaymentSub').textContent = `+ ${fmtE(insurance,0)}/mes seguros = ${fmtE(monthlyTotal,2)} real`;

    // Grid
    $('resCapital').textContent       = fmtE(principal);
    $('resTAE').textContent           = fmtP(tae, 2);
    $('resTotalInterest').textContent = fmtE(totalInterest, 0);
    $('resTotalCosts').textContent    = fmtE(openFeeAmt + notary, 0);
    $('resTotalCost').textContent     = fmtE(grandTotal + insurance*n, 0);
    $('resSaving').textContent        = down > 0 ? `−${fmtE(down)} entrada` : 'Sin entrada';

    // Bar
    const tot = principal + totalInterest + openFeeAmt + notary;
    $('barPrincipal').style.width = (principal / tot * 100).toFixed(1) + '%';
    $('barInterest').style.width  = (totalInterest / tot * 100).toFixed(1) + '%';
    $('barCosts').style.width     = ((openFeeAmt+notary) / tot * 100).toFixed(1) + '%';

    // Affordability
    const ratio = (monthlyTotal / income) * 100;
    const pct = clamp(ratio, 0, 100);
    $('affordPct').textContent = fmtP(ratio, 1);
    const fill = $('affordFill');
    fill.style.width = pct + '%';
    fill.style.background = ratio <= 25 ? 'var(--accent-2)' : ratio <= 35 ? 'var(--accent-warn)' : 'var(--accent-red)';
    const msgs = ratio <= 25
        ? '✓ Excelente — cuota cómoda según criterios bancarios (recomendado < 35%).'
        : ratio <= 35
        ? '⚠ Aceptable — rozas el límite del 35% que usan los bancos para aprobar hipotecas.'
        : '✗ Riesgo alto — los bancos suelen rechazar si la cuota supera el 35% de ingresos netos.';
    $('affordMsg').textContent = msgs;

    // Tables
    const schedule = buildSchedule(principal, rate, years);
    renderAnnualTable(schedule, years, insurance);
    renderMonthlyTable(schedule, insurance);
    renderTips(tae, ratio, down, capital, rate, years, totalInterest, principal);
}

function renderAnnualTable(sched, years, insurance) {
    let html = `<table><thead><tr>
        <th>Año</th><th>Cuota anual</th><th>Capital</th><th>Intereses</th><th>Saldo pte.</th>
    </tr></thead><tbody>`;
    for (let y = 1; y <= years; y++) {
        const slice = sched.slice((y-1)*12, y*12);
        const totQ  = slice.reduce((a,r)=>a+r.quota,0);
        const totC  = slice.reduce((a,r)=>a+r.capital,0);
        const totI  = slice.reduce((a,r)=>a+r.interest,0);
        const bal   = slice[slice.length-1].balance;
        html += `<tr>
            <td>${y}</td>
            <td>${fmtE(totQ+insurance*12, 0)}</td>
            <td class="capital-col">${fmtE(totC, 0)}</td>
            <td class="interest-col">${fmtE(totI, 0)}</td>
            <td class="balance-col">${fmtE(bal, 0)}</td>
        </tr>`;
    }
    html += '</tbody></table>';
    $('annualTableWrap').innerHTML = html;
}

function renderMonthlyTable(sched, insurance) {
    const first12 = sched.slice(0,12);
    let html = `<table><thead><tr>
        <th>Mes</th><th>Cuota</th><th>Capital</th><th>Intereses</th><th>Saldo pte.</th>
    </tr></thead><tbody>`;
    first12.forEach(r => {
        html += `<tr>
            <td>${r.month}</td>
            <td>${fmtE(r.quota+insurance, 2)}</td>
            <td class="capital-col">${fmtE(r.capital, 2)}</td>
            <td class="interest-col">${fmtE(r.interest, 2)}</td>
            <td class="balance-col">${fmtE(r.balance, 0)}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    $('monthlyTableWrap').innerHTML = html;
}

function renderTips(tae, ratio, down, capital, rate, years, totalInterest, principal) {
    const tips = [];

    // Euribor context
    tips.push({type:'info', html:`<strong>Euribor (referencia 2025–2026):</strong> El Euribor 12m cotiza entorno al 2.5–3.5%. Una hipoteca variable tipo Euribor+0.6% equivale hoy a ~TIN 3.1–4.1%. Compara siempre el <strong>TAE</strong> (${fmtP(tae,2)}), no solo el TIN.`});

    // Entrada
    if (down / capital < 0.2) {
        tips.push({type:'warn', html:`<strong>Entrada inferior al 20%:</strong> Los bancos suelen financiar como máximo el 80% del valor de tasación. Con tu entrada (${fmtP(down/capital*100,1)}), es posible que necesites un seguro de hipoteca (MI) o aval.`});
    } else {
        tips.push({type:'info', html:`<strong>Entrada ≥ 20% ✓:</strong> Tu aportación del ${fmtP(down/capital*100,1)} cumple el mínimo habitual. Mayor entrada = menos intereses totales.`});
    }

    // Affordability
    if (ratio > 35) {
        tips.push({type:'warn', html:`<strong>Ratio cuota/ingresos alto (${fmtP(ratio,1)}):</strong> Los bancos aplican el criterio del 35%. Considera ampliar el plazo o reducir el importe solicitado.`});
    }

    // Plazo largo
    if (years > 25) {
        tips.push({type:'warn', html:`<strong>Plazo de ${years} años:</strong> Pagarás ${fmtE(totalInterest,0)} en intereses. Reducir el plazo 5 años puede ahorrarte ${fmtE(totalInterest * 0.25, 0)} aproximadamente.`});
    }

    // Amortización anticipada
    const saving10 = calcMonthly(principal*0.9, rate, years) * years*12 - principal*0.9;
    tips.push({type:'info', html:`<strong>Amortización anticipada:</strong> Si en los primeros años aportas un 10% extra del capital (${fmtE(principal*0.1,0)}), podrías reducir intereses totales en ~${fmtE(saving10*0.4,0)}. Desde 2022 la comisión de amortización anticipada en hipotecas variables está <em>bonificada o exenta</em>.`});

    // Fija vs variable
    tips.push({type:'info', html:`<strong>¿Fija o variable?</strong> Con tu TIN del ${fmtP(rate,2)}: si es fija tienes estabilidad pero pagas más al inicio. Si es variable (Euribor+diferencial) y el Euribor baja podrías ahorrar, pero subes si sube el índice. Muchos bancos ofrecen <strong>hipoteca mixta</strong> (fija los primeros 5–10 años).`});

    // Seguros vinculados
    tips.push({type:'info', html:`<strong>Seguros vinculados:</strong> El banco puede ofrecer rebaja de TIN a cambio de domiciliar nómina, contratar seguro de vida o seguro de hogar. Calcula si la reducción de cuota compensa el sobrecoste del seguro vinculado.`});

    const wrap = $('tipsContent');
    wrap.innerHTML = tips.map(t =>
        `<div class="info-box ${t.type==='warn'?'warn':''}">${t.html}</div>`
    ).join('');
}

// ── SLIDER ↔ INPUT SYNC ──────────────────────────────────────────────────────
function setupField(sliderId, inputId, key, formatter, parser) {
    const slider = $(sliderId), input = $(inputId);
    const update = (fromSlider) => {
        if (fromSlider) {
            S[key] = parseFloat(slider.value);
            input.value = formatter(S[key]);
        } else {
            const v = parser(input.value);
            if (!isNaN(v)) {
                S[key] = v;
                slider.value = v;
            }
            input.value = formatter(S[key]);
        }
        // dynamic track fill
        const pct = (slider.value - slider.min) / (slider.max - slider.min) * 100;
        slider.style.background = `linear-gradient(to right, var(--accent) ${pct}%, var(--border) ${pct}%)`;
        render();
    };
    slider.addEventListener('input', ()=>update(true));
    input.addEventListener('blur',  ()=>update(false));
    input.addEventListener('keydown', e=>{ if(e.key==='Enter') update(false); });
    update(true);
}

const parseNum = s => parseFloat(s.replace(/[^\d,.-]/g,'').replace(',','.'));

setupField('capitalSlider', 'capitalInput', 'capital',
    v => fmtE(v, 0), parseNum);
setupField('downSlider', 'downInput', 'down',
    v => fmtE(v, 0), parseNum);
setupField('rateSlider', 'rateInput', 'rate',
    v => v.toLocaleString('es-ES',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' %', parseNum);
setupField('yearsSlider', 'yearsInput', 'years',
    v => v + (v===1?' año':' años'), parseNum);
setupField('openFeeSlider', 'openFeeInput', 'openFee',
    v => v.toLocaleString('es-ES',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' %', parseNum);
setupField('insuranceSlider', 'insuranceInput', 'insurance',
    v => fmtE(v, 0) + '/mes', parseNum);
setupField('notarySlider', 'notaryInput', 'notary',
    v => fmtE(v, 0), parseNum);
setupField('incomeSlider', 'incomeInput', 'income',
    v => fmtE(v, 0), parseNum);

// ── LOAN TYPE ────────────────────────────────────────────────────────────────
document.querySelectorAll('#loanTypeToggle .toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#loanTypeToggle .toggle-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const type = btn.dataset.type;
        S.loanType = type;
        const p = PRESETS[type];
        const capSlider = $('capitalSlider');
        capSlider.min = p.capitalMin; capSlider.max = p.capitalMax;
        $('capitalMin').textContent = fmtE(p.capitalMin);
        $('capitalMax').textContent = fmtE(p.capitalMax);
        $('yearsSlider').max = p.yearsMax;
        $('yearsMax').textContent = p.yearsMax + ' años';
        S.capital  = p.capitalDef;
        S.down     = Math.round(p.capitalDef * p.downPct);
        S.rate     = p.rateDef;
        S.years    = p.yearsDef;
        S.openFee  = p.openFeeDef;
        S.insurance= p.insuranceDef;
        S.notary   = p.notaryDef;
        capSlider.value = S.capital;
        $('downSlider').max = p.capitalMax * 0.3;
        $('downMax').textContent = fmtE(p.capitalMax * 0.3);
        $('downSlider').value = S.down;
        $('rateSlider').value = S.rate;
        $('yearsSlider').value = S.years;
        $('openFeeSlider').value = S.openFee;
        $('insuranceSlider').value = S.insurance;
        $('notarySlider').value = S.notary;
        ['capitalSlider','downSlider','rateSlider','yearsSlider','openFeeSlider','insuranceSlider','notarySlider'].forEach(id=>{
            const sl = $(id);
            const pct2 = (sl.value-sl.min)/(sl.max-sl.min)*100;
            sl.style.background=`linear-gradient(to right,var(--accent) ${pct2}%,var(--border) ${pct2}%)`;
        });
        $('capitalInput').value = fmtE(S.capital);
        $('downInput').value    = fmtE(S.down);
        $('rateInput').value    = S.rate.toLocaleString('es-ES',{minimumFractionDigits:2,maximumFractionDigits:2})+' %';
        $('yearsInput').value   = S.years + (S.years===1?' año':' años');
        $('openFeeInput').value = S.openFee.toLocaleString('es-ES',{minimumFractionDigits:2,maximumFractionDigits:2})+' %';
        $('insuranceInput').value = fmtE(S.insurance)+'/mes';
        $('notaryInput').value  = fmtE(S.notary);
        render();
    });
});

// ── TABS ─────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
        btn.classList.add('active');
        $('tab-' + btn.dataset.tab).classList.add('active');
    });
});

// ── INIT ─────────────────────────────────────────────────────────────────────
render();